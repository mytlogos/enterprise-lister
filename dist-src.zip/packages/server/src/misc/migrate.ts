import { startStorage } from "enterprise-core/dist/database/storages/storage";

startStorage();
