<template>
  <div>ReadHistory</div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "ReadHistory",
  mounted(): void {
    console.log("mounted");
  },
});
</script>
